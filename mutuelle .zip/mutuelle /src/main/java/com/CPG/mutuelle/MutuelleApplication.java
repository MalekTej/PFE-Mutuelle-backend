package com.CPG.mutuelle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MutuelleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MutuelleApplication.class, args);
	}

}
