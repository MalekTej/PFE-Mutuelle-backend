package com.CPG.mutuelle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MutuelleApplicationTests {

	@Test
	void contextLoads() {
	}

}
